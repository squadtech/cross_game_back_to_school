import 'dart:ui';

class MyTheme {
  static Color orange = Color(0xfff58714);
  static Color red = Color(0xfff54d63);
  static Color green = Color(0xff88e339);
}
